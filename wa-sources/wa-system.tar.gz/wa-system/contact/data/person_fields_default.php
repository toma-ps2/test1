<?php
return array (
  'name' => array ('allow_self_edit' => 1),
  'title' => array ('allow_self_edit' => 1),
  'firstname' => array ('allow_self_edit' => 1),
  'middlename' => array ('allow_self_edit' => 1),
  'lastname' => array ('allow_self_edit' => 1),
  'company_contact_id' => array('allow_self_edit' => 1),
  'jobtitle' => array ('allow_self_edit' => 1),
  'company' => array ('allow_self_edit' => 1),
  'sex' => array ('allow_self_edit' => 1),
  'email' => array ('allow_self_edit' => 1),
  'phone' => array ('allow_self_edit' => 1),
  'im' => array ('allow_self_edit' => 1),
  'address' => array ('allow_self_edit' => 1),
  'url' => array ('allow_self_edit' => 1),
  'birthday' => array ('allow_self_edit' => 1),
  'locale' => array ('allow_self_edit' => 1),
  'timezone' => array ('allow_self_edit' => 1),
  'socialnetwork' => array('allow_self_edit' => 1),
  'about' => array ('allow_self_edit' => 1),
  'categories' => array (),
);
// EOF