<?php

return array(
    'code' => 'BMD',
    'sign' => '$',
	'iso4217' => '60',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Bermudian dollar',
    'name' => array(
        array('dollar', 'dollars'),
        'BD$',
    ),
    'frac_name' => array(
        array('cent', 'cent'),
    )
);