<?php

return array(
    'code' => 'LVL',
    'sign' => 'Ls',
	'iso4217' => '428',
    'sign_position' => 0,
    'sign_delim' => ' ',
    'title' => 'Latvian lats',
    'name' => array(
        array('lats', 'lati'),
    ),
    'frac_name' => array(
        array('santim', 'santim'),
    )
);