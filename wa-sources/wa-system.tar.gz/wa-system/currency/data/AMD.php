<?php

return array(
    'code' => 'AMD',
    'sign' => 'dram',
	'iso4217' => '51',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Armenian dram',
    'name' => array(
        array('dram', 'drams'),
    ),
    'frac_name' => array(
    )
);