<?php

class waNetException extends waException
{

}
