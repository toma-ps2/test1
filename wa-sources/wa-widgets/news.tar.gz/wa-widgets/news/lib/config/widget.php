<?php

return array(
    'name' => /*_w*/('News'),
    'size' => array('2x2','1x1','2x1'),
    'img' => 'img/news.png',
    'version' => '1.4.4',
    'vendor' => 'webasyst',
);