<?php

return array(
    'php.simplexml' => array(
        'strict' => true,
        'value'  => 1,
    ),
);
