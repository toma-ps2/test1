<?php
return array(
    'item_install' => array(
        'name' => /*_w*/('Item installed'),
        'subject' => true,
    ),
    'item_disable' => array(
        'name' => /*_w*/('Item disabled'),
        'subject' => true,
    ),
    'item_update' => array(
        'name' => /*_w*/('Item updated'),
        'subject' => true,
    ),
    'item_enable' => array(
        'name' => /*_w*/('Item enabled'),
        'subject' => true,
    ),
    'item_uninstall' => array(
        'name' => /*_w*/('Item uninstalled'),
        'subject' => true,
    ),
);
