<?php
return array(
    'app.installer'=>array(
        'version' => 'latest', // 2.8.0
        'strict'  => true,
    ),
);