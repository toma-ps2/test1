<?php
class teamScheduleEventDeleteConfirmAction extends teamScheduleEventViewAction
{
}
